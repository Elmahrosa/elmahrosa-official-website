function addScanButton() {
  const fileActions = document.querySelector('.file-header-actions');
  if (!fileActions || fileActions.querySelector('.teos-scan-btn')) return;

  const btn = document.createElement('button');
  btn.className = 'btn btn-sm teos-scan-btn';
  btn.textContent = 'TEOS Scan';
  btn.style.marginLeft = '8px';
  btn.style.backgroundColor = '#238636';
  btn.style.color = '#fff';
  btn.style.border = 'none';
  btn.style.borderRadius = '6px';
  btn.style.padding = '4px 12px';
  btn.style.cursor = 'pointer';
  btn.style.fontSize = '12px';
  btn.style.fontWeight = '600';

  btn.addEventListener('click', async () => {
    const codeEl = document.querySelector('.js-file-content .blob-wrapper table, .highlight table');
    const code = codeEl ? codeEl.textContent : '';
    if (!code) return;

    btn.textContent = 'Scanning...';
    btn.disabled = true;

    try {
      const { teosApiKey = '' } = await chrome.storage.local.get('teosApiKey');
      const res = await chrome.runtime.sendMessage({ type: 'scan', code, apiKey: teosApiKey });
      if (res.ok) {
        const v = res.data.verdict || 'ALLOW';
        const s = res.data.score ?? 0;
        const icon = v === 'BLOCK' ? '\u{1F6D1}' : v === 'WARN' ? '\u26A0\uFE0F}' : v === 'REVIEW' ? '\u{1F50D}' : '\u2705';
        btn.textContent = `${icon} ${v} (${s})`;
        btn.style.backgroundColor = v === 'BLOCK' ? '#f85149' : v === 'WARN' ? '#d29922' : v === 'REVIEW' ? '#9d6fff' : '#238636';
      } else {
        btn.textContent = 'Error';
        btn.style.backgroundColor = '#f85149';
      }
    } catch {
      btn.textContent = 'Error';
      btn.style.backgroundColor = '#f85149';
    }
    btn.disabled = false;
  });

  fileActions.appendChild(btn);
}

setInterval(addScanButton, 2000);
