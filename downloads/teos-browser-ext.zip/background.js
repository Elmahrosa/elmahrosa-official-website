const BRIDGE_URL = 'https://agent-code-risk-mcp-production-b97d.up.railway.app';

async function scanCode(code, apiKey) {
  if (!apiKey) throw new Error('API key required — set in extension settings');
  const headers = { 'Content-Type': 'application/json', 'x-teos-api-key': apiKey };

  const res = await fetch(`${BRIDGE_URL}/scan`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ code }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) {
    const errBody = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${errBody.slice(0, 100)}`);
  }
  return res.json();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'scan') {
    scanCode(msg.code, msg.apiKey)
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});
