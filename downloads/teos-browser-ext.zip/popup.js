const BRIDGE_URL = 'https://agent-code-risk-mcp-production-b97d.up.railway.app';

const $ = id => document.getElementById(id);
const tabs = document.querySelectorAll('.tab');
const panels = {
  scan: $('panel-scan'),
  current: $('panel-current'),
  settings: $('panel-settings'),
};

let apiKey = '';

chrome.storage.local.get('teosApiKey', (data) => {
  apiKey = data.teosApiKey || '';
  if ($('apiKeyInput')) $('apiKeyInput').value = apiKey;
});

// Tab switching
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    Object.keys(panels).forEach(k => panels[k].classList.remove('active'));
    const panel = panels[tab.dataset.tab];
    if (panel) panel.classList.add('active');
  });
});

// Save API key
$('saveApiKeyBtn').addEventListener('click', () => {
  apiKey = $('apiKeyInput').value.trim();
  chrome.storage.local.set({ teosApiKey: apiKey }, () => {
    $('saveApiKeyBtn').textContent = 'Saved!';
    setTimeout(() => { $('saveApiKeyBtn').textContent = 'Save'; }, 1500);
  });
});

async function scanCode(code) {
  if (!apiKey) throw new Error('API key required — set in Settings tab');
  const headers = { 'Content-Type': 'application/json', 'x-teos-api-key': apiKey };

  const res = await fetch(`${BRIDGE_URL}/scan`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ code }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) {
    const errBody = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${errBody.slice(0, 100)}`);
  }
  return res.json();
}

function renderResult(result, container) {
  const v = (result.verdict || 'ALLOW').toUpperCase();
  const s = result.score ?? 0;
  const findings = Array.isArray(result.findings) ? result.findings : [];
  const reasons = Array.isArray(result.reasons) ? result.reasons : [];
  const recs = Array.isArray(result.recommendations) ? result.recommendations : [];

  container.className = `v-${v} visible`;
  container.innerHTML = `
    <div class="verdict">
      <span class="label">${v}</span>
      <span class="score">${s}/100</span>
    </div>
    ${reasons.length ? `<ul class="findings">${reasons.map(r => `<li>&bull; ${r}</li>`).join('')}</ul>` : ''}
    ${findings.length ? `<ul class="findings">${findings.map(f => {
      const sev = (f.severity || '').toLowerCase();
      const sevClass = sev === 'critical' ? 'tag-critical' : sev === 'high' ? 'tag-high' : sev === 'medium' ? 'tag-medium' : 'tag-low';
      return `<li><span class="tag ${sevClass}">${f.severity || 'info'}</span> ${f.ruleId || ''}: ${f.description || f.message || f}</li>`;
    }).join('')}</ul>` : ''}
    ${recs.length ? `<ul class="findings" style="margin-top:6px;border-top:1px solid rgba(48,54,61,0.5);padding-top:6px">${recs.map(r => `<li>&#9656; ${r}</li>`).join('')}</ul>` : ''}
  `;
}

$('scanBtn').addEventListener('click', async () => {
  const code = $('code').value.trim();
  if (!code) return;
  await doScan(code, $('result'));
});

$('scanThisPageBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => document.body.innerText,
    });
    const text = (results?.[0]?.result || '').slice(0, 10000);
    await doScan(text, $('pageResult'));
  } catch (err) {
    $('pageResult').className = 'v-BLOCK visible';
    $('pageResult').textContent = 'Error reading page: ' + err.message;
  }
});

$('scanPageBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => document.body.innerText,
    });
    const text = (results?.[0]?.result || '').slice(0, 10000);
    $('code').value = text;
    await doScan(text, $('result'));
    tabs.forEach(t => t.classList.remove('active'));
  } catch (err) { $('result').textContent = 'Error: ' + err.message; }
});

$('scanGithubBtn').addEventListener('click', async () => {
  const [tab2] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) return;
  if (!tab.url.match(/github\.com\/([\w.-]+)\/([\w.-]+)/)) {
    $('code').value = 'https://github.com/Elmahrosa/teoslinker-bot';
    await doScan($('code').value, $('result'));
    return;
  }
  $('code').value = tab.url;
  await doScan(tab.url, $('result'));
  tabs.forEach(t => t.classList.remove('active'));
  document.querySelector('[data-tab="scan"]').classList.add('active');
  panels.current.classList.remove('active');
  panels.scan.classList.add('active');
});

async function doScan(code, container) {
  $('statusText').textContent = 'Scanning...';
  container.style.display = 'none';

  try {
    const res = await chrome.runtime.sendMessage({ type: 'scan', code, apiKey });
    if (res.ok) {
      renderResult(res.data, container);
      $('statusText').textContent = 'Complete';
    } else {
      container.className = 'v-BLOCK visible';
      container.innerHTML = `<div class="verdict"><span class="label">Error</span></div><div class="err">${res.error || 'Scan failed'}</div>`;
      $('statusText').textContent = 'Error';
    }
  } catch (err) {
    container.className = 'v-BLOCK visible';
    container.innerHTML = `<div class="verdict"><span class="label">Error</span></div><div class="err">${err.message}</div>`;
    $('statusText').textContent = 'Error';
  }
}
